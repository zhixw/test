function execAjax(myScreenId, jsonData, _function,a){
    var ST_URL = "./E03-05-001_LOGIN_CTRL"
    if(typeof a != "undefined" && "button" === a.attr("type")){
        var loadingText = '<i class="fa fa-circle-o-notch fa-spin"></i> '+a.html()+'...';
        if (a.html() !== loadingText) {
            a.
            data('original-text', a.html());
            a.html(loadingText);
            a.attr('disabled', true);
        }
    }

    $.ajax({
        url : ST_URL,
        cache : false,
        type : "POST",
        data : jsonData
    })
        .done( (data, textStatus, jqXHR) => {
            _function(data);
            if(typeof a != "undefined" && "button" === a.attr('type')){
                a.html(a.data('original-text'));
                a.removeAttr("disabled");
            }
        })
        .fail( (jqXHR, textStatus, errorThrown) => {
            if(jqXHR.responseJSON){
                if(jqXHR.responseJSON["P_ST_RESULT"]){
                    if(jqXHR.responseJSON["P_ST_RESULT"] == "1"){
                        //ログイン制御エラー
                        setMessage(jqXHR.responseJSON);
                    } else if(jqXHR.responseJSON["P_ST_RESULT"] == "9"){
                        //予期せぬエラー
                        var messageId = jqXHR.responseJSON["P_ST_MESSAGEID"];
                        var message = jqXHR.responseJSON["P_ST_MESSAGE"];
                        alert(messageId + "：" + message);
                    }
                } else {
                    alert("エラーが発生しました\n" + errorThrown);
                }
            } else {
                alert("エラーが発生しました\n" + errorThrown);
            }
            if(typeof a != "undefined" && "button" === a.attr('type')){
                a.html(a.data('original-text'));
                a.removeAttr("disabled");
            }
        })
        .always( (data) => {

        })
}
