function linkedDatetimepickerSet(dateFromToObject) {

    let to = dateFromToObject.to.targetId;
    let from = dateFromToObject.from.targetId;
    let toInput = to + " input";
    let fromInput = from + " input";
    var dateNow = new Date();

    $(from).datetimepicker({
        ignoreReadonly: true,
        autoclose: true,
        useCurrent: false,
        format: 'YYYY-MM-DD HH:mm:ss',
        defaultDate: moment(dateNow).hours(0).minutes(0).seconds(0),
        /*initialDate: 'day',*/
        /*viewDate:moment(dateNow).hours(0).minutes(0).seconds(0).milliseconds(0),*/
        sideBySide: true
    });
    $(to).datetimepicker({
        ignoreReadonly: true,
        autoclose: true,
        useCurrent: false,
        format: 'YYYY-MM-DD HH:mm:ss',
        defaultDate: moment(dateNow).hours(23).minutes(59).seconds(59),
        sideBySide: true
    });
    $(from).on('change.datetimepicker', function (e) {
        $(to).datetimepicker('minDate', e.date);
    });

    $(to).on('change.datetimepicker', function (e) {
        $(from).datetimepicker('maxDate', e.date);
    });

    $(toInput).blur(function () {
        $(to).datetimepicker('hide');
    });

    $(fromInput).blur(function () {
        $(from).datetimepicker('hide');
    });

}


//status
//on switchon
//off switchoff
//else.. switch
function switchButton(toggleObj, status) {

    let target = $(toggleObj.targetId);
    let on = toggleObj.on, off = toggleObj.off;

    let hasOn = target.hasClass(on.style);
    let hasOff = target.hasClass(off.style);

    if (hasOn == hasOff) {
        // have no style or have both style
        throw "error switchButton";
    }

    let item = ((typeof status !== 'boolean') && hasOn) || status === true ? {
        remove: on.style,
        add: off.style,
        text: off.text
    } : {
        remove: off.style,
        add: on.style,
        text: on.text
    }

    target.removeClass(item.remove).addClass(item.add).text(item.text);
};


var language = {
    "sProcessing": "処理中...",
    "sLengthMenu": "_MENU_ 件表示",
    "sZeroRecords": "データはありません。",
    "sInfo": " _TOTAL_ 件中 _START_ から _END_ まで表示",
    "sInfoEmpty": " 0 件中 0 から 0 まで表示",
    "sInfoFiltered": "（全 _MAX_ 件より抽出）",
    "sInfoPostFix": "",
    "sSearch": "検索:",
    "sUrl": "",
    "oPaginate": {
        "sFirst": "先頭",
        "sPrevious": "前",
        "sNext": "次",
        "sLast": "最終"
    },
    "select": {
        /*style : "single"*/
        rows: {
            /*_: "Selected %d rows",
            0: "Click a row to select it",
            1: "Selected 1 row"*/
            _: "",
            0: "",
            1: ""
        }
    }
};

//画面共通メッセージ
var message = {
    //logout
    "I7701": "ログアウトします、よろしいですか？",
    //upload
    "I7702": "アップロードします、よろしいですか？",
    //inform stop
    "I7703": "通知停止します、よろしいですか？",
    // retry
    "I7704": "リトライします、よろしいですか？",
    //change password conform message
    "I7705": "{0}を登録しますが、よろしいですか？"
}


//--- set multi parameters to [msg] witch should be formatted ---//
//-- {i} <- arg[i+1] --//
//-- Example:createMessage('got {0}-{1} tested', Google, Bing) => 'got Google-Bing tested.'--//
function createMessage(msg) {
    let returnVal;
    // have replace arguments
    let argLen = arguments.length;

    if (argLen > 1) {
        for (let i = 1; i < argLen; i++) {
            let replaceVal = arguments[i];
            let replaceTarget = '{' + (i - 1) + '}'
            msg = msg.replace(replaceTarget, replaceVal);
        }
    }

    returnVal = msg

    return returnVal;
}

/*--get response data be processed before doing other things--*/

/*--when has MESSAGEHTML then show msgDIV and return false--*/
function respDataPreProcess(data) {
    let bReturn = true; // default return code:true -> no error
    let jsonData;
    // check data format -> json ? :{json}
    if (typeof (data["P_ST_RESULT"]) == "undefined") {
        try {
            // convert to json data
            let obj = $.parseJSON(data);
            if (typeof obj == 'object' && obj) {
                jsonData = obj;
            } else {
                // not a json format data: maybe file stream
                return bReturn;
            }
        } catch (e) {
            // not a json format data: maybe file stream
            return bReturn;
        }
    } else {
        jsonData = data;
    }

    // has 'P_ST_MESSAGEHTML' part means has error message to show
    if (jsonData["P_ST_MESSAGEHTML"]) {
        bReturn = false;
        // show msg
        setMessage(jsonData);
    }

    return bReturn;
}

/*--set and show message div--*/
function setMessage(jsonData) {
    $("#msgDIV").html(jsonData["P_ST_MESSAGEHTML"]);
    $('#msgDIV').removeClass('d-none');
    $('#msgDIV').show();
}

//clear message before next request
function clearMessage() {
    $('#msgDIV').addClass('d-none');
    $('#msgDIV').hide();
}

//------------------//
//-- Download file stream common process --//
//------------------//
function createDownloadData(data) {
    var returnData;
    // decode data via atob()
    var content = window.atob(data);

    // content is empty?
    if (content.length > 0) {
        let unit8Array = new Uint8Array(content.length);
        for (var i = 0; i < content.length; i++) {
            unit8Array[i] = content.charCodeAt(i);
        }

        // Blob dataを作成
        returnData = new Blob([unit8Array.buffer]);
        return returnData;
    } else {
        alert("got no data from contents");
        return null;
    }
}

//------------------//
//-- Prepare download <a>'s attrs and click it --//
//------------------//
function triggerDownloadLink(a_id, fileName, blobData) {
    let jquery_id_str = '#' + a_id;
    // BlobをBlob URL Schemeへ変換してリンクタグへ埋め込む
    $(jquery_id_str).prop("href", window.URL.createObjectURL(blobData));
    $(jquery_id_str).prop("download", fileName);
    // リンクをクリックする
    $(jquery_id_str)[0].click();
}

//------------------//
//--- 1:true | 0:false --//
//------------------//
function checkboxValueConvert(len) {
    if (1 == Number(len)) {
        // checkbox checked:true
        return true;
    } else {
        // checkbox checked:false
        return false;
    }
}