function execAjax(myScreenId, jsonData, _function){
	var ST_URL = "./E03-05-001_LOGIN_CTRL"

	$.ajax({
		url : ST_URL,
		cache : false,
		type : "POST",
		data : jsonData
	})
	.done( (data, textStatus, jqXHR) => {
		_function(data);
	})
	.fail( (jqXHR, textStatus, errorThrown) => {
		if(jqXHR.responseJSON){
			if(jqXHR.responseJSON["P_ST_RESULT"]){
				if(jqXHR.responseJSON["P_ST_RESULT"] == "1"){
					//ログイン制御エラー
					$("#msgDIV").html(jqXHR.responseJSON["P_ST_MESSAGEHTML"]);
					$("#msgDIV").show();
				} else if(jqXHR.responseJSON["P_ST_RESULT"] == "9"){
					//予期せぬエラー
					/*var messageId = data["P_ST_MESSAGEID"];
					var message = data["P_ST_MESSAGE"];
					alert(messageId + "：" + message);*/
					var messageId = jqXHR.responseJSON["P_ST_MESSAGEID"];
					var message = jqXHR.responseJSON["P_ST_MESSAGE"];
					$("#P_ST_MESSAGEID").text(messageId);
					$("#P_ST_MESSAGE").text(message);
                    $('#menuError').modal('show');
					// alert(messageId + "：" + message);
				}
			} else {
				alert("エラーが発生しました\n" + errorThrown);
			}
		} else {
			alert("エラーが発生しました\n" + errorThrown);
		}
	})
	.always( (data) => {

	})
  /*  setTimeout(function() {
        e.html($this.data('original-text'));
        e.removeAttr("disabled");
        // $this.re
    }, 5000);*/
}
